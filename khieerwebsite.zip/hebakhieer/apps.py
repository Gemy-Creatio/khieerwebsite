from django.apps import AppConfig


class HebakhieerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hebakhieer'
