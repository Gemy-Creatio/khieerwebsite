from django.apps import AppConfig


class DesignkhieerConfig(AppConfig):
    name = 'designkhieer'
